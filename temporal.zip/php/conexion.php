<?php
$servidor='localhost';
$usuario='root';
$contra='';
$bd='e_j_m_o';
$conexion=mysqli_connect($servidor,$usuario, $contra, $bd) or die ("Ha ocurrido un problema en la conexion");
?>